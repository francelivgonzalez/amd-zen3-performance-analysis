#!/usr/bin/env bash
# MOCK DEMO ONLY. Run from repository root after placing mock_demo.cpp in demo/.
set -euo pipefail
mkdir -p demo/results
# Compile demonstration program, separate from course project benchmarks.
g++ -O2 -std=c++17 -pthread demo/mock_demo.cpp -o demo/mock_demo
printf 'experiment,configuration,elapsed_ms,ns_per_access,checksum\n' > demo/results/demo_runs.csv
# Cache: working-set sizes around L1, L2 and L3 capacities.
for kib in 16 32 64 256 512 1024 32768 65536; do
  taskset -c 0 ./demo/mock_demo cache "$kib" | tee -a demo/results/demo_runs.csv
done
# Sequential and random access use the same data and number of reads.
for mode in sequential random; do
  taskset -c 0 ./demo/mock_demo memory "$mode" | tee -a demo/results/demo_runs.csv
done
# Use 0-7 for at most 8 threads; expand affinity for 16 threads.
for t in 1 2 4 8 16; do
  taskset -c 0-15 ./demo/mock_demo multicore "$t" | tee -a demo/results/demo_runs.csv
done
# perf measures the entire process. This is a sanity check, not per-phase IPC.
perf stat -e cycles,instructions,cache-references,cache-misses -- taskset -c 0 ./demo/mock_demo memory random 2>&1 | tee demo/results/perf_memory_random.txt
